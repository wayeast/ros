#include <stdlib.h>
#include <ros/ros.h>
#include <std_msgs/Int32.h>

int main(int argc, char **argv)
{
   ros::init(argc, argv, "publish_wifi_strength");
   ros::NodeHandle nh;

   ros::Publisher wifi_reporter = nh.advertise<std_msgs::Int32>(
          "wifi_ss", 100);
   std_msgs::Int32 msg;
   ros::Rate rate(2);
/*
   while(ros::ok())
   {
      msg.data = std::system("iwconfig wlan0|grep Quality|cut -d'=' -f2|cut -d'/' -f1");
      ROS_INFO_STREAM("Sending value " << msg.data << " to wifi_ss");
      wifi_reporter.publish(msg);
      rate.sleep();
   }
   */
}
